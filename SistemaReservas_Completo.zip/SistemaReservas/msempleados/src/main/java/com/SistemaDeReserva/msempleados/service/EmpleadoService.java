package com.SistemaDeReserva.msempleados.service;
import com.SistemaDeReserva.msempleados.dto.*;
import com.SistemaDeReserva.msempleados.exception.EmpleadoNotFoundException;
import com.SistemaDeReserva.msempleados.model.Empleado;
import com.SistemaDeReserva.msempleados.repository.EmpleadoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class EmpleadoService {
    private final EmpleadoRepository repo;
    public List<EmpleadoResponseDTO> obtenerTodos(){return repo.findByActivoTrue().stream().map(this::toDTO).collect(Collectors.toList());}
    public EmpleadoResponseDTO obtenerPorId(Long id){return toDTO(repo.findById(id).orElseThrow(()->new EmpleadoNotFoundException(id)));}
    public List<EmpleadoResponseDTO> porCargo(String cargo){return repo.findByCargo(cargo).stream().map(this::toDTO).collect(Collectors.toList());}
    public EmpleadoResponseDTO crear(EmpleadoRequestDTO dto){
        Empleado e=Empleado.builder().nombre(dto.getNombre()).apellido(dto.getApellido())
                .cargo(dto.getCargo()).email(dto.getEmail()).telefono(dto.getTelefono()).activo(true).build();
        return toDTO(repo.save(e));}
    public EmpleadoResponseDTO actualizar(Long id,EmpleadoRequestDTO dto){
        Empleado e=repo.findById(id).orElseThrow(()->new EmpleadoNotFoundException(id));
        e.setNombre(dto.getNombre());e.setApellido(dto.getApellido());e.setCargo(dto.getCargo());
        e.setEmail(dto.getEmail());e.setTelefono(dto.getTelefono());
        return toDTO(repo.save(e));}
    public void desactivar(Long id){Empleado e=repo.findById(id).orElseThrow(()->new EmpleadoNotFoundException(id));e.setActivo(false);repo.save(e);}
    private EmpleadoResponseDTO toDTO(Empleado e){return EmpleadoResponseDTO.builder().idEmpleado(e.getIdEmpleado())
            .nombre(e.getNombre()).apellido(e.getApellido()).cargo(e.getCargo()).email(e.getEmail()).telefono(e.getTelefono()).activo(e.getActivo()).build();}
}
