package com.SistemaDeReserva.msreservas.dto;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalTime;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ReservaRequestDTO {
    @NotNull private Long idCliente;
    @NotNull private Long idMesa;
    @NotNull private LocalDate fechaReserva;
    @NotNull private LocalTime horaInicio;
    @NotNull private LocalTime horaFin;
    @NotNull @Min(1) @Max(20) private Integer cantidadPersonas;
    private String observaciones;
}
