package com.SistemaDeReserva.msclientes.controller;
import com.SistemaDeReserva.msclientes.dto.*;
import com.SistemaDeReserva.msclientes.service.ClienteService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/v1/clientes") @RequiredArgsConstructor
public class ClienteController {
    private final ClienteService svc;
    @GetMapping public ResponseEntity<List<ClienteResponseDTO>> todos(){return ResponseEntity.ok(svc.obtenerTodos());}
    @GetMapping("/{id}") public ResponseEntity<ClienteResponseDTO> porId(@PathVariable Long id){return ResponseEntity.ok(svc.obtenerPorId(id));}
    @PostMapping public ResponseEntity<ClienteResponseDTO> crear(@Valid @RequestBody ClienteRequestDTO dto){
        return ResponseEntity.status(HttpStatus.CREATED).body(svc.crearCliente(dto));}
    @PutMapping("/{id}") public ResponseEntity<ClienteResponseDTO> actualizar(@PathVariable Long id,@Valid @RequestBody ClienteRequestDTO dto){
        return ResponseEntity.ok(svc.actualizarCliente(id,dto));}
    @DeleteMapping("/{id}") public ResponseEntity<Void> desactivar(@PathVariable Long id){svc.desactivarCliente(id);return ResponseEntity.noContent().build();}
}
