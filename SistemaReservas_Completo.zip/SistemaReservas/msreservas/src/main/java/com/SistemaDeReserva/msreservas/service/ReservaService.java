package com.SistemaDeReserva.msreservas.service;
import com.SistemaDeReserva.msreservas.dto.*;
import com.SistemaDeReserva.msreservas.exception.ReservaNotFoundException;
import com.SistemaDeReserva.msreservas.model.Reserva;
import com.SistemaDeReserva.msreservas.repository.ReservaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class ReservaService {
    private final ReservaRepository repo;
    public List<ReservaResponseDTO> obtenerTodas(){return repo.findAll().stream().map(this::toDTO).collect(Collectors.toList());}
    public ReservaResponseDTO obtenerPorId(Long id){return toDTO(repo.findById(id).orElseThrow(()->new ReservaNotFoundException(id)));}
    public List<ReservaResponseDTO> porCliente(Long idCliente){return repo.findByIdCliente(idCliente).stream().map(this::toDTO).collect(Collectors.toList());}
    public ReservaResponseDTO crear(ReservaRequestDTO dto){
        Reserva r=Reserva.builder().idCliente(dto.getIdCliente()).idMesa(dto.getIdMesa())
                .fechaReserva(dto.getFechaReserva()).horaInicio(dto.getHoraInicio()).horaFin(dto.getHoraFin())
                .cantidadPersonas(dto.getCantidadPersonas()).observaciones(dto.getObservaciones()).estado("PENDIENTE").build();
        return toDTO(repo.save(r));}
    public ReservaResponseDTO cambiarEstado(Long id,String estado){
        Reserva r=repo.findById(id).orElseThrow(()->new ReservaNotFoundException(id));
        r.setEstado(estado);return toDTO(repo.save(r));}
    public void eliminar(Long id){repo.findById(id).orElseThrow(()->new ReservaNotFoundException(id));repo.deleteById(id);}
    private ReservaResponseDTO toDTO(Reserva r){return ReservaResponseDTO.builder().idReserva(r.getIdReserva())
            .idCliente(r.getIdCliente()).idMesa(r.getIdMesa()).fechaReserva(r.getFechaReserva())
            .horaInicio(r.getHoraInicio()).horaFin(r.getHoraFin()).cantidadPersonas(r.getCantidadPersonas())
            .estado(r.getEstado()).observaciones(r.getObservaciones()).build();}
}
