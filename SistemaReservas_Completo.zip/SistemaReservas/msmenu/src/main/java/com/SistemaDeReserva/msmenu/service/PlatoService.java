package com.SistemaDeReserva.msmenu.service;
import com.SistemaDeReserva.msmenu.dto.*;
import com.SistemaDeReserva.msmenu.exception.PlatoNotFoundException;
import com.SistemaDeReserva.msmenu.model.Plato;
import com.SistemaDeReserva.msmenu.repository.PlatoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class PlatoService {
    private final PlatoRepository repo;
    public List<PlatoResponseDTO> obtenerTodos(){return repo.findAll().stream().map(this::toDTO).collect(Collectors.toList());}
    public List<PlatoResponseDTO> disponibles(){return repo.findByDisponibleTrue().stream().map(this::toDTO).collect(Collectors.toList());}
    public List<PlatoResponseDTO> porCategoria(String cat){return repo.findByCategoria(cat).stream().map(this::toDTO).collect(Collectors.toList());}
    public PlatoResponseDTO obtenerPorId(Long id){return toDTO(repo.findById(id).orElseThrow(()->new PlatoNotFoundException(id)));}
    public PlatoResponseDTO crear(PlatoRequestDTO dto){
        Plato p=Plato.builder().nombre(dto.getNombre()).descripcion(dto.getDescripcion())
                .precio(dto.getPrecio()).categoria(dto.getCategoria()).disponible(true).build();
        return toDTO(repo.save(p));}
    public PlatoResponseDTO actualizar(Long id,PlatoRequestDTO dto){
        Plato p=repo.findById(id).orElseThrow(()->new PlatoNotFoundException(id));
        p.setNombre(dto.getNombre());p.setDescripcion(dto.getDescripcion());p.setPrecio(dto.getPrecio());p.setCategoria(dto.getCategoria());
        return toDTO(repo.save(p));}
    public PlatoResponseDTO cambiarDisponibilidad(Long id,Boolean disponible){
        Plato p=repo.findById(id).orElseThrow(()->new PlatoNotFoundException(id));
        p.setDisponible(disponible);return toDTO(repo.save(p));}
    public void eliminar(Long id){repo.findById(id).orElseThrow(()->new PlatoNotFoundException(id));repo.deleteById(id);}
    private PlatoResponseDTO toDTO(Plato p){return PlatoResponseDTO.builder().idPlato(p.getIdPlato())
            .nombre(p.getNombre()).descripcion(p.getDescripcion()).precio(p.getPrecio())
            .categoria(p.getCategoria()).disponible(p.getDisponible()).build();}
}
