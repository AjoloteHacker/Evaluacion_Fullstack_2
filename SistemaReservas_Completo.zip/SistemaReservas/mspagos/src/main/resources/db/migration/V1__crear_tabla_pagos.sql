CREATE TABLE IF NOT EXISTS pagos (
    id_pago     BIGINT         AUTO_INCREMENT PRIMARY KEY,
    id_reserva  BIGINT         NOT NULL,
    monto       DECIMAL(10,2)  NOT NULL,
    metodo_pago VARCHAR(50)    NOT NULL,
    estado      VARCHAR(30)    NOT NULL DEFAULT 'PENDIENTE',
    fecha_pago  DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP
);
