package com.SistemaDeReserva.msreportes.dto;
import jakarta.validation.constraints.*;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ReporteRequestDTO {
    @NotBlank private String tipo;
    private String descripcion;
    private String datos;
}
