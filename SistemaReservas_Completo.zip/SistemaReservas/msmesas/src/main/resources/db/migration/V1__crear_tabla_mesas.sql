CREATE TABLE IF NOT EXISTS mesas (
    id_mesa    BIGINT AUTO_INCREMENT PRIMARY KEY,
    numero     INT          NOT NULL UNIQUE,
    capacidad  INT          NOT NULL,
    ubicacion  VARCHAR(100) NOT NULL,
    disponible BOOLEAN      NOT NULL DEFAULT TRUE
);
