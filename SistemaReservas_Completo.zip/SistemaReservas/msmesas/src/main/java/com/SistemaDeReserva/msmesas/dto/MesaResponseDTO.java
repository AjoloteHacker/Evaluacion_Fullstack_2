package com.SistemaDeReserva.msmesas.dto;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class MesaResponseDTO {
    private Long idMesa;
    private Integer numero,capacidad;
    private String ubicacion;
    private Boolean disponible;
}
