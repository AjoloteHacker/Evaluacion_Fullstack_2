package com.SistemaDeReserva.mspedidos.controller;
import com.SistemaDeReserva.mspedidos.dto.*;
import com.SistemaDeReserva.mspedidos.service.PedidoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/v1/pedidos") @RequiredArgsConstructor
public class PedidoController {
    private final PedidoService svc;
    @GetMapping public ResponseEntity<List<PedidoResponseDTO>> todos(){return ResponseEntity.ok(svc.obtenerTodos());}
    @GetMapping("/{id}") public ResponseEntity<PedidoResponseDTO> porId(@PathVariable Long id){return ResponseEntity.ok(svc.obtenerPorId(id));}
    @GetMapping("/reserva/{idReserva}") public ResponseEntity<List<PedidoResponseDTO>> porReserva(@PathVariable Long idReserva){return ResponseEntity.ok(svc.porReserva(idReserva));}
    @PostMapping public ResponseEntity<PedidoResponseDTO> crear(@Valid @RequestBody PedidoRequestDTO dto){return ResponseEntity.status(HttpStatus.CREATED).body(svc.crear(dto));}
    @PatchMapping("/{id}/estado") public ResponseEntity<PedidoResponseDTO> estado(@PathVariable Long id,@RequestParam String estado){return ResponseEntity.ok(svc.cambiarEstado(id,estado));}
    @DeleteMapping("/{id}") public ResponseEntity<Void> eliminar(@PathVariable Long id){svc.eliminar(id);return ResponseEntity.noContent().build();}
}
