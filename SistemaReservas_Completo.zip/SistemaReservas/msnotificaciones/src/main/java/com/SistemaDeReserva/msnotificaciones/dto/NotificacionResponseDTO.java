package com.SistemaDeReserva.msnotificaciones.dto;
import lombok.*;
import java.time.LocalDateTime;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class NotificacionResponseDTO {
    private Long idNotificacion,idCliente;
    private String tipo,mensaje;
    private LocalDateTime fechaEnvio;
    private Boolean leida;
}
