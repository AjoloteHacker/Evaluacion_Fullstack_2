package com.SistemaDeReserva.msclientes.dto;
import jakarta.validation.constraints.*;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ClienteRequestDTO {
    @NotBlank @Size(min=2,max=100) private String nombre;
    @NotBlank @Size(min=2,max=100) private String apellido;
    @NotBlank @Email private String email;
    @NotBlank @Pattern(regexp="^[+]?[0-9]{8,15}$") private String telefono;
}
