package com.SistemaDeReserva.msmesas.repository;
import com.SistemaDeReserva.msmesas.model.Mesa;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface MesaRepository extends JpaRepository<Mesa,Long> {
    List<Mesa> findByDisponibleTrue();
    boolean existsByNumero(Integer numero);
}
