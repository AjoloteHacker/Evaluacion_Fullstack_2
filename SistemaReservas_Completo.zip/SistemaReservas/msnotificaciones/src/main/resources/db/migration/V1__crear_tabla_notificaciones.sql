CREATE TABLE IF NOT EXISTS notificaciones (
    id_notificacion BIGINT        AUTO_INCREMENT PRIMARY KEY,
    id_cliente      BIGINT        NOT NULL,
    tipo            VARCHAR(50)   NOT NULL,
    mensaje         VARCHAR(1000) NOT NULL,
    fecha_envio     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    leida           BOOLEAN       NOT NULL DEFAULT FALSE
);
