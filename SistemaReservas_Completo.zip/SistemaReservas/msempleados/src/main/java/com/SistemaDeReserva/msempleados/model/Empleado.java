package com.SistemaDeReserva.msempleados.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
@Entity @Table(name="empleados")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Empleado {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id_empleado") private Long idEmpleado;
    @NotBlank @Size(min=2,max=100) @Column(nullable=false,length=100) private String nombre;
    @NotBlank @Size(min=2,max=100) @Column(nullable=false,length=100) private String apellido;
    @NotBlank @Column(nullable=false,length=100) private String cargo;
    @NotBlank @Email @Column(nullable=false,unique=true,length=150) private String email;
    @NotBlank @Pattern(regexp="^[+]?[0-9]{8,15}$") @Column(nullable=false,length=20) private String telefono;
    @Column(nullable=false) @Builder.Default private Boolean activo=true;
}
