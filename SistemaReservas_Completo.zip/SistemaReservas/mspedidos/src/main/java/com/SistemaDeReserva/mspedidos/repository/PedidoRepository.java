package com.SistemaDeReserva.mspedidos.repository;
import com.SistemaDeReserva.mspedidos.model.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface PedidoRepository extends JpaRepository<Pedido,Long> {
    List<Pedido> findByIdReserva(Long idReserva);
    List<Pedido> findByEstado(String estado);
}
