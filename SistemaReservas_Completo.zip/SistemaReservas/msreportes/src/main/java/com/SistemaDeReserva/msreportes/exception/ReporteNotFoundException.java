package com.SistemaDeReserva.msreportes.exception;
public class ReporteNotFoundException extends RuntimeException {
    public ReporteNotFoundException(Long id){super("Reporte con ID "+id+" no encontrado");}
}
