package com.SistemaDeReserva.msmenu.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
@Entity @Table(name="platos")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Plato {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id_plato") private Long idPlato;
    @NotBlank @Column(nullable=false,length=150) private String nombre;
    @Column(length=500) private String descripcion;
    @NotNull @DecimalMin(value="0.0",inclusive=false,message="Precio debe ser mayor a 0")
    @Column(nullable=false,precision=10,scale=2) private BigDecimal precio;
    @NotBlank @Column(nullable=false,length=100) private String categoria;
    @Column(nullable=false) @Builder.Default private Boolean disponible=true;
}
