package com.SistemaReservas.Evaluacion.msmenu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsmenuApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsmenuApplication.class, args);
	}

}
