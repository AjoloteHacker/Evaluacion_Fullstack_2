package com.SistemaDeReserva.msreservas.exception;
public class ReservaNotFoundException extends RuntimeException {
    public ReservaNotFoundException(Long id){super("Reserva con ID "+id+" no encontrada");}
}
