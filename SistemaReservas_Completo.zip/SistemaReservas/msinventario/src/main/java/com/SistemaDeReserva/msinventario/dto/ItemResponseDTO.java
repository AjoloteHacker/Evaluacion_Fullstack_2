package com.SistemaDeReserva.msinventario.dto;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ItemResponseDTO {
    private Long idItem;
    private String nombre,descripcion,unidad;
    private Integer cantidad,stockMinimo;
    private Boolean stockBajo;
}
