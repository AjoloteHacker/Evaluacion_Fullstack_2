package com.SistemaDeReserva.mspagos.exception;
public class PagoNotFoundException extends RuntimeException {
    public PagoNotFoundException(Long id){super("Pago con ID "+id+" no encontrado");}
}
