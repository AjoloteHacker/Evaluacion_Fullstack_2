package com.SistemaDeReserva.msmenu.controller;
import com.SistemaDeReserva.msmenu.dto.*;
import com.SistemaDeReserva.msmenu.service.PlatoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/v1/menu") @RequiredArgsConstructor
public class PlatoController {
    private final PlatoService svc;
    @GetMapping public ResponseEntity<List<PlatoResponseDTO>> todos(){return ResponseEntity.ok(svc.obtenerTodos());}
    @GetMapping("/disponibles") public ResponseEntity<List<PlatoResponseDTO>> disponibles(){return ResponseEntity.ok(svc.disponibles());}
    @GetMapping("/categoria/{cat}") public ResponseEntity<List<PlatoResponseDTO>> porCategoria(@PathVariable String cat){return ResponseEntity.ok(svc.porCategoria(cat));}
    @GetMapping("/{id}") public ResponseEntity<PlatoResponseDTO> porId(@PathVariable Long id){return ResponseEntity.ok(svc.obtenerPorId(id));}
    @PostMapping public ResponseEntity<PlatoResponseDTO> crear(@Valid @RequestBody PlatoRequestDTO dto){return ResponseEntity.status(HttpStatus.CREATED).body(svc.crear(dto));}
    @PutMapping("/{id}") public ResponseEntity<PlatoResponseDTO> actualizar(@PathVariable Long id,@Valid @RequestBody PlatoRequestDTO dto){return ResponseEntity.ok(svc.actualizar(id,dto));}
    @PatchMapping("/{id}/disponibilidad") public ResponseEntity<PlatoResponseDTO> disponibilidad(@PathVariable Long id,@RequestParam Boolean disponible){return ResponseEntity.ok(svc.cambiarDisponibilidad(id,disponible));}
    @DeleteMapping("/{id}") public ResponseEntity<Void> eliminar(@PathVariable Long id){svc.eliminar(id);return ResponseEntity.noContent().build();}
}
