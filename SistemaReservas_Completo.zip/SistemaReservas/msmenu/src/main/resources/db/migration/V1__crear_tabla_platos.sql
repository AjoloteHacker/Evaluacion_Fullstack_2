CREATE TABLE IF NOT EXISTS platos (
    id_plato    BIGINT         AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(150)   NOT NULL,
    descripcion VARCHAR(500),
    precio      DECIMAL(10,2)  NOT NULL,
    categoria   VARCHAR(100)   NOT NULL,
    disponible  BOOLEAN        NOT NULL DEFAULT TRUE
);
