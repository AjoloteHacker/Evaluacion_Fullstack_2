package com.SistemaDeReserva.mspagos.repository;
import com.SistemaDeReserva.mspagos.model.Pago;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface PagoRepository extends JpaRepository<Pago,Long> {
    List<Pago> findByIdReserva(Long idReserva);
    Optional<Pago> findByIdReservaAndEstado(Long idReserva,String estado);
}
