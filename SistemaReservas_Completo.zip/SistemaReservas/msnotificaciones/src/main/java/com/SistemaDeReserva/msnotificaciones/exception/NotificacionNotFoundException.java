package com.SistemaDeReserva.msnotificaciones.exception;
public class NotificacionNotFoundException extends RuntimeException {
    public NotificacionNotFoundException(Long id){super("Notificacion con ID "+id+" no encontrada");}
}
