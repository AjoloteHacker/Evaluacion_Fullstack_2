package com.SistemaDeReserva.msreportes.service;
import com.SistemaDeReserva.msreportes.dto.*;
import com.SistemaDeReserva.msreportes.exception.ReporteNotFoundException;
import com.SistemaDeReserva.msreportes.model.Reporte;
import com.SistemaDeReserva.msreportes.repository.ReporteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class ReporteService {
    private final ReporteRepository repo;
    public List<ReporteResponseDTO> obtenerTodos(){return repo.findAll().stream().map(this::toDTO).collect(Collectors.toList());}
    public ReporteResponseDTO obtenerPorId(Long id){return toDTO(repo.findById(id).orElseThrow(()->new ReporteNotFoundException(id)));}
    public List<ReporteResponseDTO> porTipo(String tipo){return repo.findByTipo(tipo).stream().map(this::toDTO).collect(Collectors.toList());}
    public ReporteResponseDTO crear(ReporteRequestDTO dto){
        Reporte r=Reporte.builder().tipo(dto.getTipo()).descripcion(dto.getDescripcion())
                .datos(dto.getDatos()).fechaGeneracion(LocalDateTime.now()).build();
        return toDTO(repo.save(r));}
    public void eliminar(Long id){repo.findById(id).orElseThrow(()->new ReporteNotFoundException(id));repo.deleteById(id);}
    private ReporteResponseDTO toDTO(Reporte r){return ReporteResponseDTO.builder().idReporte(r.getIdReporte())
            .tipo(r.getTipo()).descripcion(r.getDescripcion()).datos(r.getDatos()).fechaGeneracion(r.getFechaGeneracion()).build();}
}
