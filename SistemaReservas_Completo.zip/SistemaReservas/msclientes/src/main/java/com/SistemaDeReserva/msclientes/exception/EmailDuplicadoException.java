package com.SistemaDeReserva.msclientes.exception;
public class EmailDuplicadoException extends RuntimeException {
    public EmailDuplicadoException(String email){super("Email "+email+" ya registrado");}
}
