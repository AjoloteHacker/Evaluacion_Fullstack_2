package com.SistemaDeReserva.msinventario.service;
import com.SistemaDeReserva.msinventario.dto.*;
import com.SistemaDeReserva.msinventario.exception.ItemNotFoundException;
import com.SistemaDeReserva.msinventario.model.ItemInventario;
import com.SistemaDeReserva.msinventario.repository.ItemInventarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class ItemInventarioService {
    private final ItemInventarioRepository repo;
    public List<ItemResponseDTO> obtenerTodos(){return repo.findAll().stream().map(this::toDTO).collect(Collectors.toList());}
    public ItemResponseDTO obtenerPorId(Long id){return toDTO(repo.findById(id).orElseThrow(()->new ItemNotFoundException(id)));}
    public List<ItemResponseDTO> stockBajo(){return repo.findStockBajo().stream().map(this::toDTO).collect(Collectors.toList());}
    public ItemResponseDTO crear(ItemRequestDTO dto){
        ItemInventario i=ItemInventario.builder().nombre(dto.getNombre()).descripcion(dto.getDescripcion())
                .cantidad(dto.getCantidad()).unidad(dto.getUnidad()).stockMinimo(dto.getStockMinimo()).build();
        return toDTO(repo.save(i));}
    public ItemResponseDTO actualizar(Long id,ItemRequestDTO dto){
        ItemInventario i=repo.findById(id).orElseThrow(()->new ItemNotFoundException(id));
        i.setNombre(dto.getNombre());i.setDescripcion(dto.getDescripcion());i.setCantidad(dto.getCantidad());
        i.setUnidad(dto.getUnidad());i.setStockMinimo(dto.getStockMinimo());
        return toDTO(repo.save(i));}
    public ItemResponseDTO ajustarCantidad(Long id,Integer cantidad){
        ItemInventario i=repo.findById(id).orElseThrow(()->new ItemNotFoundException(id));
        i.setCantidad(i.getCantidad()+cantidad);return toDTO(repo.save(i));}
    public void eliminar(Long id){repo.findById(id).orElseThrow(()->new ItemNotFoundException(id));repo.deleteById(id);}
    private ItemResponseDTO toDTO(ItemInventario i){return ItemResponseDTO.builder().idItem(i.getIdItem())
            .nombre(i.getNombre()).descripcion(i.getDescripcion()).cantidad(i.getCantidad())
            .unidad(i.getUnidad()).stockMinimo(i.getStockMinimo()).stockBajo(i.getCantidad()<=i.getStockMinimo()).build();}
}
