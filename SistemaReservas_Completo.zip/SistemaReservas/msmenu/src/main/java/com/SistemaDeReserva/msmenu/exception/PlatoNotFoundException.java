package com.SistemaDeReserva.msmenu.exception;
public class PlatoNotFoundException extends RuntimeException {
    public PlatoNotFoundException(Long id){super("Plato con ID "+id+" no encontrado");}
}
