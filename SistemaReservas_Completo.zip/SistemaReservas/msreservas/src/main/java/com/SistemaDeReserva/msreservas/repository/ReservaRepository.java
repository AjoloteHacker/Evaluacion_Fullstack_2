package com.SistemaDeReserva.msreservas.repository;
import com.SistemaDeReserva.msreservas.model.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface ReservaRepository extends JpaRepository<Reserva,Long> {
    List<Reserva> findByIdCliente(Long idCliente);
    List<Reserva> findByEstado(String estado);
}
