package com.SistemaDeReserva.msreportes.controller;
import com.SistemaDeReserva.msreportes.dto.*;
import com.SistemaDeReserva.msreportes.service.ReporteService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/v1/reportes") @RequiredArgsConstructor
public class ReporteController {
    private final ReporteService svc;
    @GetMapping public ResponseEntity<List<ReporteResponseDTO>> todos(){return ResponseEntity.ok(svc.obtenerTodos());}
    @GetMapping("/{id}") public ResponseEntity<ReporteResponseDTO> porId(@PathVariable Long id){return ResponseEntity.ok(svc.obtenerPorId(id));}
    @GetMapping("/tipo/{tipo}") public ResponseEntity<List<ReporteResponseDTO>> porTipo(@PathVariable String tipo){return ResponseEntity.ok(svc.porTipo(tipo));}
    @PostMapping public ResponseEntity<ReporteResponseDTO> crear(@Valid @RequestBody ReporteRequestDTO dto){return ResponseEntity.status(HttpStatus.CREATED).body(svc.crear(dto));}
    @DeleteMapping("/{id}") public ResponseEntity<Void> eliminar(@PathVariable Long id){svc.eliminar(id);return ResponseEntity.noContent().build();}
}
