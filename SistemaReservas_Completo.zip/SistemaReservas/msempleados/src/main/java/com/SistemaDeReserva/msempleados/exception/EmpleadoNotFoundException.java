package com.SistemaDeReserva.msempleados.exception;
public class EmpleadoNotFoundException extends RuntimeException {
    public EmpleadoNotFoundException(Long id){super("Empleado con ID "+id+" no encontrado");}
}
