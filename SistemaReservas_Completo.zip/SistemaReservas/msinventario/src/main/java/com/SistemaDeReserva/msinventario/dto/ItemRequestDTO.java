package com.SistemaDeReserva.msinventario.dto;
import jakarta.validation.constraints.*;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ItemRequestDTO {
    @NotBlank private String nombre;
    private String descripcion;
    @NotNull @Min(0) private Integer cantidad;
    @NotBlank private String unidad;
    @NotNull @Min(0) private Integer stockMinimo;
}
