package com.SistemaDeReserva.msmenu.dto;
import lombok.*;
import java.math.BigDecimal;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class PlatoResponseDTO {
    private Long idPlato;
    private String nombre,descripcion,categoria;
    private BigDecimal precio;
    private Boolean disponible;
}
