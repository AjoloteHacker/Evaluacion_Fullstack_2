package com.SistemaDeReserva.msreservas.dto;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalTime;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ReservaResponseDTO {
    private Long idReserva,idCliente,idMesa;
    private LocalDate fechaReserva;
    private LocalTime horaInicio,horaFin;
    private Integer cantidadPersonas;
    private String estado,observaciones;
}
