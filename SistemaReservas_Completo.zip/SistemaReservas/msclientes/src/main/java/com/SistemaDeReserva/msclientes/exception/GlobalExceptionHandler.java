package com.SistemaDeReserva.msclientes.exception;
import org.springframework.http.*;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(ClienteNotFoundException.class)
    public ResponseEntity<Map<String,String>> notFound(ClienteNotFoundException e){
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error",e.getMessage()));}
    @ExceptionHandler(EmailDuplicadoException.class)
    public ResponseEntity<Map<String,String>> duplicado(EmailDuplicadoException e){
        return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error",e.getMessage()));}
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String,String>> validation(MethodArgumentNotValidException e){
        Map<String,String> err=new HashMap<>();
        e.getBindingResult().getAllErrors().forEach(er->err.put(((FieldError)er).getField(),er.getDefaultMessage()));
        return ResponseEntity.badRequest().body(err);}
}
