package com.SistemaReservas.Evaluacion.msmenu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsmenuApplicationTests {

	@Test
	void contextLoads() {
	}

}
