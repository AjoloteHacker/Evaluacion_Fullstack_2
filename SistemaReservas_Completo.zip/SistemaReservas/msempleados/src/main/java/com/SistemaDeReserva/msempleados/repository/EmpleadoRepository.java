package com.SistemaDeReserva.msempleados.repository;
import com.SistemaDeReserva.msempleados.model.Empleado;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface EmpleadoRepository extends JpaRepository<Empleado,Long> {
    List<Empleado> findByActivoTrue();
    List<Empleado> findByCargo(String cargo);
    boolean existsByEmail(String email);
}
