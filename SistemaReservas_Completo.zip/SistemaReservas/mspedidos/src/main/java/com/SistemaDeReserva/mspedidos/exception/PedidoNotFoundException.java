package com.SistemaDeReserva.mspedidos.exception;
public class PedidoNotFoundException extends RuntimeException {
    public PedidoNotFoundException(Long id){super("Pedido con ID "+id+" no encontrado");}
}
