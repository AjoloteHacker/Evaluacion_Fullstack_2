CREATE TABLE IF NOT EXISTS reportes (
    id_reporte        BIGINT       AUTO_INCREMENT PRIMARY KEY,
    tipo              VARCHAR(100) NOT NULL,
    fecha_generacion  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    descripcion       VARCHAR(500),
    datos             TEXT
);
