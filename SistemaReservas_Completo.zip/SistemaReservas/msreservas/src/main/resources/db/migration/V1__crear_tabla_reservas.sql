CREATE TABLE IF NOT EXISTS reservas (
    id_reserva        BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_cliente        BIGINT       NOT NULL,
    id_mesa           BIGINT       NOT NULL,
    fecha_reserva     DATE         NOT NULL,
    hora_inicio       TIME         NOT NULL,
    hora_fin          TIME         NOT NULL,
    cantidad_personas INT          NOT NULL,
    estado            VARCHAR(30)  NOT NULL DEFAULT 'PENDIENTE',
    observaciones     VARCHAR(500)
);
