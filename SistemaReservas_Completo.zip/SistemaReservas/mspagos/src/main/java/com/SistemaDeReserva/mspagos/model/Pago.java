package com.SistemaDeReserva.mspagos.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
@Entity @Table(name="pagos")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Pago {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id_pago") private Long idPago;
    @NotNull @Column(name="id_reserva",nullable=false) private Long idReserva;
    @NotNull @DecimalMin(value="0.0",inclusive=false) @Column(nullable=false,precision=10,scale=2) private BigDecimal monto;
    @NotBlank @Column(name="metodo_pago",nullable=false,length=50) private String metodoPago;
    @Column(nullable=false,length=30) @Builder.Default private String estado="PENDIENTE";
    @Column(name="fecha_pago") @Builder.Default private LocalDateTime fechaPago=LocalDateTime.now();
}
