package com.SistemaDeReserva.msmesas.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
@Entity @Table(name="mesas")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Mesa {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id_mesa") private Long idMesa;
    @NotNull @Min(1) @Column(nullable=false,unique=true) private Integer numero;
    @NotNull @Min(1) @Max(20) @Column(nullable=false) private Integer capacidad;
    @NotBlank @Column(nullable=false,length=100) private String ubicacion;
    @Column(nullable=false) @Builder.Default private Boolean disponible=true;
}
