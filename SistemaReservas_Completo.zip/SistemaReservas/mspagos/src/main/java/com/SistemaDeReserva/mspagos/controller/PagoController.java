package com.SistemaDeReserva.mspagos.controller;
import com.SistemaDeReserva.mspagos.dto.*;
import com.SistemaDeReserva.mspagos.service.PagoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/v1/pagos") @RequiredArgsConstructor
public class PagoController {
    private final PagoService svc;
    @GetMapping public ResponseEntity<List<PagoResponseDTO>> todos(){return ResponseEntity.ok(svc.obtenerTodos());}
    @GetMapping("/{id}") public ResponseEntity<PagoResponseDTO> porId(@PathVariable Long id){return ResponseEntity.ok(svc.obtenerPorId(id));}
    @GetMapping("/reserva/{idReserva}") public ResponseEntity<List<PagoResponseDTO>> porReserva(@PathVariable Long idReserva){return ResponseEntity.ok(svc.porReserva(idReserva));}
    @PostMapping public ResponseEntity<PagoResponseDTO> crear(@Valid @RequestBody PagoRequestDTO dto){return ResponseEntity.status(HttpStatus.CREATED).body(svc.crear(dto));}
    @PatchMapping("/{id}/confirmar") public ResponseEntity<PagoResponseDTO> confirmar(@PathVariable Long id){return ResponseEntity.ok(svc.confirmar(id));}
    @PatchMapping("/{id}/anular") public ResponseEntity<PagoResponseDTO> anular(@PathVariable Long id){return ResponseEntity.ok(svc.anular(id));}
}
