package com.SistemaDeReserva.msreportes.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;
@Entity @Table(name="reportes")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Reporte {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id_reporte") private Long idReporte;
    @NotBlank @Column(nullable=false,length=100) private String tipo;
    @Column(name="fecha_generacion") @Builder.Default private LocalDateTime fechaGeneracion=LocalDateTime.now();
    @Column(length=500) private String descripcion;
    @Column(columnDefinition="TEXT") private String datos;
}
