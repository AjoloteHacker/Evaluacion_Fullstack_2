package com.SistemaDeReserva.msclientes.dto;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ClienteResponseDTO {
    private Long idCliente;
    private String nombre,apellido,email,telefono;
    private Boolean activo;
}
