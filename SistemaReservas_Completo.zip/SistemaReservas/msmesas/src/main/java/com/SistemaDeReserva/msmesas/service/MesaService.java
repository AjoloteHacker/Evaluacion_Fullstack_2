package com.SistemaDeReserva.msmesas.service;
import com.SistemaDeReserva.msmesas.dto.*;
import com.SistemaDeReserva.msmesas.exception.MesaNotFoundException;
import com.SistemaDeReserva.msmesas.model.Mesa;
import com.SistemaDeReserva.msmesas.repository.MesaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class MesaService {
    private final MesaRepository repo;
    public List<MesaResponseDTO> obtenerTodas(){return repo.findAll().stream().map(this::toDTO).collect(Collectors.toList());}
    public List<MesaResponseDTO> disponibles(){return repo.findByDisponibleTrue().stream().map(this::toDTO).collect(Collectors.toList());}
    public MesaResponseDTO obtenerPorId(Long id){return toDTO(repo.findById(id).orElseThrow(()->new MesaNotFoundException(id)));}
    public MesaResponseDTO crear(MesaRequestDTO dto){
        Mesa m=Mesa.builder().numero(dto.getNumero()).capacidad(dto.getCapacidad()).ubicacion(dto.getUbicacion()).disponible(true).build();
        return toDTO(repo.save(m));}
    public MesaResponseDTO actualizar(Long id,MesaRequestDTO dto){
        Mesa m=repo.findById(id).orElseThrow(()->new MesaNotFoundException(id));
        m.setNumero(dto.getNumero());m.setCapacidad(dto.getCapacidad());m.setUbicacion(dto.getUbicacion());
        return toDTO(repo.save(m));}
    public MesaResponseDTO cambiarDisponibilidad(Long id,Boolean disponible){
        Mesa m=repo.findById(id).orElseThrow(()->new MesaNotFoundException(id));
        m.setDisponible(disponible);return toDTO(repo.save(m));}
    public void eliminar(Long id){repo.findById(id).orElseThrow(()->new MesaNotFoundException(id));repo.deleteById(id);}
    private MesaResponseDTO toDTO(Mesa m){return MesaResponseDTO.builder().idMesa(m.getIdMesa())
            .numero(m.getNumero()).capacidad(m.getCapacidad()).ubicacion(m.getUbicacion()).disponible(m.getDisponible()).build();}
}
