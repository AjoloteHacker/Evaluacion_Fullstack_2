package com.SistemaDeReserva.msreportes.dto;
import lombok.*;
import java.time.LocalDateTime;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ReporteResponseDTO {
    private Long idReporte;
    private String tipo,descripcion,datos;
    private LocalDateTime fechaGeneracion;
}
