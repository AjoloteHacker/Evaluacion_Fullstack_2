package com.SistemaDeReserva.msmenu.dto;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class PlatoRequestDTO {
    @NotBlank private String nombre;
    private String descripcion;
    @NotNull @DecimalMin(value="0.0",inclusive=false) private BigDecimal precio;
    @NotBlank private String categoria;
}
