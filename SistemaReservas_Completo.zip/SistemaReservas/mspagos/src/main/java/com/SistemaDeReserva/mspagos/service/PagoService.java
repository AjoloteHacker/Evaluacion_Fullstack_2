package com.SistemaDeReserva.mspagos.service;
import com.SistemaDeReserva.mspagos.dto.*;
import com.SistemaDeReserva.mspagos.exception.PagoNotFoundException;
import com.SistemaDeReserva.mspagos.model.Pago;
import com.SistemaDeReserva.mspagos.repository.PagoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class PagoService {
    private final PagoRepository repo;
    public List<PagoResponseDTO> obtenerTodos(){return repo.findAll().stream().map(this::toDTO).collect(Collectors.toList());}
    public PagoResponseDTO obtenerPorId(Long id){return toDTO(repo.findById(id).orElseThrow(()->new PagoNotFoundException(id)));}
    public List<PagoResponseDTO> porReserva(Long idReserva){return repo.findByIdReserva(idReserva).stream().map(this::toDTO).collect(Collectors.toList());}
    public PagoResponseDTO crear(PagoRequestDTO dto){
        Pago p=Pago.builder().idReserva(dto.getIdReserva()).monto(dto.getMonto())
                .metodoPago(dto.getMetodoPago()).estado("PENDIENTE").fechaPago(LocalDateTime.now()).build();
        return toDTO(repo.save(p));}
    public PagoResponseDTO confirmar(Long id){
        Pago p=repo.findById(id).orElseThrow(()->new PagoNotFoundException(id));
        p.setEstado("CONFIRMADO");p.setFechaPago(LocalDateTime.now());return toDTO(repo.save(p));}
    public PagoResponseDTO anular(Long id){
        Pago p=repo.findById(id).orElseThrow(()->new PagoNotFoundException(id));
        p.setEstado("ANULADO");return toDTO(repo.save(p));}
    private PagoResponseDTO toDTO(Pago p){return PagoResponseDTO.builder().idPago(p.getIdPago())
            .idReserva(p.getIdReserva()).monto(p.getMonto()).metodoPago(p.getMetodoPago())
            .estado(p.getEstado()).fechaPago(p.getFechaPago()).build();}
}
