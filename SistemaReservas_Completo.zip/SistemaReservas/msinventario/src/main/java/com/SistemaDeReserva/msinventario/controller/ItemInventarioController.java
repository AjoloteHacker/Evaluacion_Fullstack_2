package com.SistemaDeReserva.msinventario.controller;
import com.SistemaDeReserva.msinventario.dto.*;
import com.SistemaDeReserva.msinventario.service.ItemInventarioService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/v1/inventario") @RequiredArgsConstructor
public class ItemInventarioController {
    private final ItemInventarioService svc;
    @GetMapping public ResponseEntity<List<ItemResponseDTO>> todos(){return ResponseEntity.ok(svc.obtenerTodos());}
    @GetMapping("/{id}") public ResponseEntity<ItemResponseDTO> porId(@PathVariable Long id){return ResponseEntity.ok(svc.obtenerPorId(id));}
    @GetMapping("/stock-bajo") public ResponseEntity<List<ItemResponseDTO>> stockBajo(){return ResponseEntity.ok(svc.stockBajo());}
    @PostMapping public ResponseEntity<ItemResponseDTO> crear(@Valid @RequestBody ItemRequestDTO dto){return ResponseEntity.status(HttpStatus.CREATED).body(svc.crear(dto));}
    @PutMapping("/{id}") public ResponseEntity<ItemResponseDTO> actualizar(@PathVariable Long id,@Valid @RequestBody ItemRequestDTO dto){return ResponseEntity.ok(svc.actualizar(id,dto));}
    @PatchMapping("/{id}/cantidad") public ResponseEntity<ItemResponseDTO> ajustar(@PathVariable Long id,@RequestParam Integer cantidad){return ResponseEntity.ok(svc.ajustarCantidad(id,cantidad));}
    @DeleteMapping("/{id}") public ResponseEntity<Void> eliminar(@PathVariable Long id){svc.eliminar(id);return ResponseEntity.noContent().build();}
}
