package com.SistemaDeReserva.msclientes.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity @Table(name = "clientes")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Cliente {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_cliente") private Long idCliente;
    @NotBlank(message = "Nombre obligatorio") @Size(min=2,max=100)
    @Column(nullable=false,length=100) private String nombre;
    @NotBlank(message = "Apellido obligatorio") @Size(min=2,max=100)
    @Column(nullable=false,length=100) private String apellido;
    @NotBlank @Email(message="Email inválido")
    @Column(nullable=false,unique=true,length=150) private String email;
    @NotBlank @Pattern(regexp="^[+]?[0-9]{8,15}$",message="Teléfono inválido")
    @Column(nullable=false,length=20) private String telefono;
    @Column(nullable=false) @Builder.Default private Boolean activo = true;
}
