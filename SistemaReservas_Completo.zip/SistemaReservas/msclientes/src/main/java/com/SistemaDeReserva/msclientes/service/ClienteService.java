package com.SistemaDeReserva.msclientes.service;
import com.SistemaDeReserva.msclientes.dto.*;
import com.SistemaDeReserva.msclientes.exception.*;
import com.SistemaDeReserva.msclientes.model.Cliente;
import com.SistemaDeReserva.msclientes.repository.ClienteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class ClienteService {
    private final ClienteRepository repo;
    public List<ClienteResponseDTO> obtenerTodos(){return repo.findByActivoTrue().stream().map(this::toDTO).collect(Collectors.toList());}
    public ClienteResponseDTO obtenerPorId(Long id){return toDTO(repo.findById(id).orElseThrow(()->new ClienteNotFoundException(id)));}
    public ClienteResponseDTO crearCliente(ClienteRequestDTO dto){
        if(repo.existsByEmail(dto.getEmail()))throw new EmailDuplicadoException(dto.getEmail());
        return toDTO(repo.save(Cliente.builder().nombre(dto.getNombre()).apellido(dto.getApellido())
                .email(dto.getEmail()).telefono(dto.getTelefono()).activo(true).build()));}
    public ClienteResponseDTO actualizarCliente(Long id,ClienteRequestDTO dto){
        Cliente c=repo.findById(id).orElseThrow(()->new ClienteNotFoundException(id));
        repo.findByEmail(dto.getEmail()).ifPresent(o->{if(!o.getIdCliente().equals(id))throw new EmailDuplicadoException(dto.getEmail());});
        c.setNombre(dto.getNombre());c.setApellido(dto.getApellido());c.setEmail(dto.getEmail());c.setTelefono(dto.getTelefono());
        return toDTO(repo.save(c));}
    public void desactivarCliente(Long id){Cliente c=repo.findById(id).orElseThrow(()->new ClienteNotFoundException(id));c.setActivo(false);repo.save(c);}
    private ClienteResponseDTO toDTO(Cliente c){return ClienteResponseDTO.builder().idCliente(c.getIdCliente())
            .nombre(c.getNombre()).apellido(c.getApellido()).email(c.getEmail()).telefono(c.getTelefono()).activo(c.getActivo()).build();}
}
