package com.SistemaDeReserva.mspedidos.service;
import com.SistemaDeReserva.mspedidos.dto.*;
import com.SistemaDeReserva.mspedidos.exception.PedidoNotFoundException;
import com.SistemaDeReserva.mspedidos.model.Pedido;
import com.SistemaDeReserva.mspedidos.repository.PedidoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class PedidoService {
    private final PedidoRepository repo;
    public List<PedidoResponseDTO> obtenerTodos(){return repo.findAll().stream().map(this::toDTO).collect(Collectors.toList());}
    public PedidoResponseDTO obtenerPorId(Long id){return toDTO(repo.findById(id).orElseThrow(()->new PedidoNotFoundException(id)));}
    public List<PedidoResponseDTO> porReserva(Long idReserva){return repo.findByIdReserva(idReserva).stream().map(this::toDTO).collect(Collectors.toList());}
    public PedidoResponseDTO crear(PedidoRequestDTO dto){
        Pedido p=Pedido.builder().idReserva(dto.getIdReserva()).idPlato(dto.getIdPlato())
                .cantidad(dto.getCantidad()).precioUnitario(dto.getPrecioUnitario()).estado("PENDIENTE").build();
        return toDTO(repo.save(p));}
    public PedidoResponseDTO cambiarEstado(Long id,String estado){
        Pedido p=repo.findById(id).orElseThrow(()->new PedidoNotFoundException(id));
        p.setEstado(estado);return toDTO(repo.save(p));}
    public void eliminar(Long id){repo.findById(id).orElseThrow(()->new PedidoNotFoundException(id));repo.deleteById(id);}
    private PedidoResponseDTO toDTO(Pedido p){
        return PedidoResponseDTO.builder().idPedido(p.getIdPedido()).idReserva(p.getIdReserva())
                .idPlato(p.getIdPlato()).cantidad(p.getCantidad()).precioUnitario(p.getPrecioUnitario())
                .total(p.getPrecioUnitario().multiply(java.math.BigDecimal.valueOf(p.getCantidad())))
                .estado(p.getEstado()).build();}
}
