package com.SistemaDeReserva.msclientes.exception;
public class ClienteNotFoundException extends RuntimeException {
    public ClienteNotFoundException(Long id){super("Cliente con ID "+id+" no encontrado");}
    public ClienteNotFoundException(String msg){super(msg);}
}
