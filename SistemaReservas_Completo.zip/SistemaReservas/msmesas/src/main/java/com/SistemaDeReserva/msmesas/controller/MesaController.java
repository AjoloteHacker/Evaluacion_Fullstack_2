package com.SistemaDeReserva.msmesas.controller;
import com.SistemaDeReserva.msmesas.dto.*;
import com.SistemaDeReserva.msmesas.service.MesaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/v1/mesas") @RequiredArgsConstructor
public class MesaController {
    private final MesaService svc;
    @GetMapping public ResponseEntity<List<MesaResponseDTO>> todas(){return ResponseEntity.ok(svc.obtenerTodas());}
    @GetMapping("/disponibles") public ResponseEntity<List<MesaResponseDTO>> disponibles(){return ResponseEntity.ok(svc.disponibles());}
    @GetMapping("/{id}") public ResponseEntity<MesaResponseDTO> porId(@PathVariable Long id){return ResponseEntity.ok(svc.obtenerPorId(id));}
    @PostMapping public ResponseEntity<MesaResponseDTO> crear(@Valid @RequestBody MesaRequestDTO dto){return ResponseEntity.status(HttpStatus.CREATED).body(svc.crear(dto));}
    @PutMapping("/{id}") public ResponseEntity<MesaResponseDTO> actualizar(@PathVariable Long id,@Valid @RequestBody MesaRequestDTO dto){return ResponseEntity.ok(svc.actualizar(id,dto));}
    @PatchMapping("/{id}/disponibilidad") public ResponseEntity<MesaResponseDTO> disponibilidad(@PathVariable Long id,@RequestParam Boolean disponible){return ResponseEntity.ok(svc.cambiarDisponibilidad(id,disponible));}
    @DeleteMapping("/{id}") public ResponseEntity<Void> eliminar(@PathVariable Long id){svc.eliminar(id);return ResponseEntity.noContent().build();}
}
