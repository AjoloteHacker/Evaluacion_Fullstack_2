package com.SistemaDeReserva.msmesas.dto;
import jakarta.validation.constraints.*;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class MesaRequestDTO {
    @NotNull @Min(1) private Integer numero;
    @NotNull @Min(1) @Max(20) private Integer capacidad;
    @NotBlank private String ubicacion;
}
