package com.SistemaDeReserva.msreservas.controller;
import com.SistemaDeReserva.msreservas.dto.*;
import com.SistemaDeReserva.msreservas.service.ReservaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/v1/reservas") @RequiredArgsConstructor
public class ReservaController {
    private final ReservaService svc;
    @GetMapping public ResponseEntity<List<ReservaResponseDTO>> todas(){return ResponseEntity.ok(svc.obtenerTodas());}
    @GetMapping("/{id}") public ResponseEntity<ReservaResponseDTO> porId(@PathVariable Long id){return ResponseEntity.ok(svc.obtenerPorId(id));}
    @GetMapping("/cliente/{idCliente}") public ResponseEntity<List<ReservaResponseDTO>> porCliente(@PathVariable Long idCliente){return ResponseEntity.ok(svc.porCliente(idCliente));}
    @PostMapping public ResponseEntity<ReservaResponseDTO> crear(@Valid @RequestBody ReservaRequestDTO dto){return ResponseEntity.status(HttpStatus.CREATED).body(svc.crear(dto));}
    @PatchMapping("/{id}/estado") public ResponseEntity<ReservaResponseDTO> estado(@PathVariable Long id,@RequestParam String estado){return ResponseEntity.ok(svc.cambiarEstado(id,estado));}
    @DeleteMapping("/{id}") public ResponseEntity<Void> eliminar(@PathVariable Long id){svc.eliminar(id);return ResponseEntity.noContent().build();}
}
