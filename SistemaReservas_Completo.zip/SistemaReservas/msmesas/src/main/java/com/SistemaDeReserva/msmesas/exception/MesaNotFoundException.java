package com.SistemaDeReserva.msmesas.exception;
public class MesaNotFoundException extends RuntimeException {
    public MesaNotFoundException(Long id){super("Mesa con ID "+id+" no encontrada");}
}
