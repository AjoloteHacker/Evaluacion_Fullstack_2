package com.SistemaDeReserva.msclientes.repository;
import com.SistemaDeReserva.msclientes.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface ClienteRepository extends JpaRepository<Cliente,Long> {
    List<Cliente> findByActivoTrue();
    boolean existsByEmail(String email);
    Optional<Cliente> findByEmail(String email);
}
