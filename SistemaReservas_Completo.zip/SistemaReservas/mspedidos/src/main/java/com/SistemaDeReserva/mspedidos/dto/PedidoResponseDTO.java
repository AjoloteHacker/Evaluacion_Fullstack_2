package com.SistemaDeReserva.mspedidos.dto;
import lombok.*;
import java.math.BigDecimal;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class PedidoResponseDTO {
    private Long idPedido,idReserva,idPlato;
    private Integer cantidad;
    private BigDecimal precioUnitario,total;
    private String estado;
}
