package com.SistemaDeReserva.msempleados.controller;
import com.SistemaDeReserva.msempleados.dto.*;
import com.SistemaDeReserva.msempleados.service.EmpleadoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/v1/empleados") @RequiredArgsConstructor
public class EmpleadoController {
    private final EmpleadoService svc;
    @GetMapping public ResponseEntity<List<EmpleadoResponseDTO>> todos(){return ResponseEntity.ok(svc.obtenerTodos());}
    @GetMapping("/{id}") public ResponseEntity<EmpleadoResponseDTO> porId(@PathVariable Long id){return ResponseEntity.ok(svc.obtenerPorId(id));}
    @GetMapping("/cargo/{cargo}") public ResponseEntity<List<EmpleadoResponseDTO>> porCargo(@PathVariable String cargo){return ResponseEntity.ok(svc.porCargo(cargo));}
    @PostMapping public ResponseEntity<EmpleadoResponseDTO> crear(@Valid @RequestBody EmpleadoRequestDTO dto){return ResponseEntity.status(HttpStatus.CREATED).body(svc.crear(dto));}
    @PutMapping("/{id}") public ResponseEntity<EmpleadoResponseDTO> actualizar(@PathVariable Long id,@Valid @RequestBody EmpleadoRequestDTO dto){return ResponseEntity.ok(svc.actualizar(id,dto));}
    @DeleteMapping("/{id}") public ResponseEntity<Void> desactivar(@PathVariable Long id){svc.desactivar(id);return ResponseEntity.noContent().build();}
}
