package com.SistemaDeReserva.msnotificaciones.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;
@Entity @Table(name="notificaciones")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Notificacion {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id_notificacion") private Long idNotificacion;
    @NotNull @Column(name="id_cliente",nullable=false) private Long idCliente;
    @NotBlank @Column(nullable=false,length=50) private String tipo;
    @NotBlank @Column(nullable=false,length=1000) private String mensaje;
    @Column(name="fecha_envio") @Builder.Default private LocalDateTime fechaEnvio=LocalDateTime.now();
    @Column(nullable=false) @Builder.Default private Boolean leida=false;
}
