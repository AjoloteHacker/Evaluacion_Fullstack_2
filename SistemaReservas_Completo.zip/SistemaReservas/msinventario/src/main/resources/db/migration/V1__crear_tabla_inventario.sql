CREATE TABLE IF NOT EXISTS inventario (
    id_item       BIGINT       AUTO_INCREMENT PRIMARY KEY,
    nombre        VARCHAR(150) NOT NULL,
    descripcion   VARCHAR(500),
    cantidad      INT          NOT NULL DEFAULT 0,
    unidad        VARCHAR(50)  NOT NULL,
    stock_minimo  INT          NOT NULL DEFAULT 0
);
