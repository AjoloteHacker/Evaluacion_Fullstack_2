package com.SistemaDeReserva.msnotificaciones.controller;
import com.SistemaDeReserva.msnotificaciones.dto.*;
import com.SistemaDeReserva.msnotificaciones.service.NotificacionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/v1/notificaciones") @RequiredArgsConstructor
public class NotificacionController {
    private final NotificacionService svc;
    @GetMapping public ResponseEntity<List<NotificacionResponseDTO>> todas(){return ResponseEntity.ok(svc.obtenerTodas());}
    @GetMapping("/cliente/{idCliente}") public ResponseEntity<List<NotificacionResponseDTO>> porCliente(@PathVariable Long idCliente){return ResponseEntity.ok(svc.porCliente(idCliente));}
    @GetMapping("/cliente/{idCliente}/no-leidas") public ResponseEntity<List<NotificacionResponseDTO>> noLeidas(@PathVariable Long idCliente){return ResponseEntity.ok(svc.noLeidas(idCliente));}
    @PostMapping public ResponseEntity<NotificacionResponseDTO> crear(@Valid @RequestBody NotificacionRequestDTO dto){return ResponseEntity.status(HttpStatus.CREATED).body(svc.crear(dto));}
    @PatchMapping("/{id}/leer") public ResponseEntity<NotificacionResponseDTO> leer(@PathVariable Long id){return ResponseEntity.ok(svc.marcarLeida(id));}
}
