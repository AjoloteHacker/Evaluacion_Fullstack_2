package com.SistemaDeReserva.msreservas.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity @Table(name="reservas")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Reserva {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id_reserva") private Long idReserva;
    @NotNull(message="ID cliente obligatorio") @Column(name="id_cliente",nullable=false) private Long idCliente;
    @NotNull(message="ID mesa obligatorio") @Column(name="id_mesa",nullable=false) private Long idMesa;
    @NotNull(message="Fecha obligatoria") @Column(name="fecha_reserva",nullable=false) private LocalDate fechaReserva;
    @NotNull(message="Hora inicio obligatoria") @Column(name="hora_inicio",nullable=false) private LocalTime horaInicio;
    @NotNull(message="Hora fin obligatoria") @Column(name="hora_fin",nullable=false) private LocalTime horaFin;
    @NotNull @Min(value=1,message="Mínimo 1 persona") @Max(value=20,message="Máximo 20 personas")
    @Column(name="cantidad_personas",nullable=false) private Integer cantidadPersonas;
    @NotBlank @Column(nullable=false,length=30) @Builder.Default private String estado="PENDIENTE";
    @Column(length=500) private String observaciones;
}
