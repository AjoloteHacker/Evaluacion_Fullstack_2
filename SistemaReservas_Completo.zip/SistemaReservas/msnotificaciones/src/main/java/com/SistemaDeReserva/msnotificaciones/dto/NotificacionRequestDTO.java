package com.SistemaDeReserva.msnotificaciones.dto;
import jakarta.validation.constraints.*;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class NotificacionRequestDTO {
    @NotNull private Long idCliente;
    @NotBlank private String tipo;
    @NotBlank @Size(max=1000) private String mensaje;
}
