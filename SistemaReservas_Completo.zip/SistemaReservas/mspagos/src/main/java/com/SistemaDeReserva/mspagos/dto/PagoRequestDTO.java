package com.SistemaDeReserva.mspagos.dto;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class PagoRequestDTO {
    @NotNull private Long idReserva;
    @NotNull @DecimalMin(value="0.0",inclusive=false) private BigDecimal monto;
    @NotBlank private String metodoPago;
}
