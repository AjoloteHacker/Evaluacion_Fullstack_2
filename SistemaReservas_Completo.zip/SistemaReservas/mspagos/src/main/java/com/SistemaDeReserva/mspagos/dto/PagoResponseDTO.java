package com.SistemaDeReserva.mspagos.dto;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class PagoResponseDTO {
    private Long idPago,idReserva;
    private BigDecimal monto;
    private String metodoPago,estado;
    private LocalDateTime fechaPago;
}
