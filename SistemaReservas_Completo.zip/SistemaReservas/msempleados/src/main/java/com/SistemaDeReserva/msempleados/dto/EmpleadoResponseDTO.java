package com.SistemaDeReserva.msempleados.dto;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class EmpleadoResponseDTO {
    private Long idEmpleado;
    private String nombre,apellido,cargo,email,telefono;
    private Boolean activo;
}
