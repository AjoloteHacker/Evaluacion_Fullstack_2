package com.SistemaDeReserva.mspedidos.dto;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class PedidoRequestDTO {
    @NotNull private Long idReserva;
    @NotNull private Long idPlato;
    @NotNull @Min(1) private Integer cantidad;
    @NotNull @DecimalMin("0.0") private BigDecimal precioUnitario;
}
