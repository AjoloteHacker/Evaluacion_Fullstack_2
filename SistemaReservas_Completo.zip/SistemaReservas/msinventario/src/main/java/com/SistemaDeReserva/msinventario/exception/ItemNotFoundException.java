package com.SistemaDeReserva.msinventario.exception;
public class ItemNotFoundException extends RuntimeException {
    public ItemNotFoundException(Long id){super("Item con ID "+id+" no encontrado en inventario");}
}
