package com.SistemaDeReserva.msinventario.repository;
import com.SistemaDeReserva.msinventario.model.ItemInventario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
public interface ItemInventarioRepository extends JpaRepository<ItemInventario,Long> {
    @Query("SELECT i FROM ItemInventario i WHERE i.cantidad <= i.stockMinimo")
    List<ItemInventario> findStockBajo();
}
