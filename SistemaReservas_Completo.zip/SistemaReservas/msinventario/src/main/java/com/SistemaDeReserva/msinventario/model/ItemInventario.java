package com.SistemaDeReserva.msinventario.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
@Entity @Table(name="inventario")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ItemInventario {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id_item") private Long idItem;
    @NotBlank @Column(nullable=false,length=150) private String nombre;
    @Column(length=500) private String descripcion;
    @NotNull @Min(0) @Column(nullable=false) private Integer cantidad;
    @NotBlank @Column(nullable=false,length=50) private String unidad;
    @NotNull @Min(0) @Column(name="stock_minimo",nullable=false) private Integer stockMinimo;
}
