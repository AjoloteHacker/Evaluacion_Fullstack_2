package com.SistemaDeReserva.msnotificaciones.service;
import com.SistemaDeReserva.msnotificaciones.dto.*;
import com.SistemaDeReserva.msnotificaciones.exception.NotificacionNotFoundException;
import com.SistemaDeReserva.msnotificaciones.model.Notificacion;
import com.SistemaDeReserva.msnotificaciones.repository.NotificacionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class NotificacionService {
    private final NotificacionRepository repo;
    public List<NotificacionResponseDTO> obtenerTodas(){return repo.findAll().stream().map(this::toDTO).collect(Collectors.toList());}
    public List<NotificacionResponseDTO> porCliente(Long idCliente){return repo.findByIdCliente(idCliente).stream().map(this::toDTO).collect(Collectors.toList());}
    public List<NotificacionResponseDTO> noLeidas(Long idCliente){return repo.findByIdClienteAndLeidaFalse(idCliente).stream().map(this::toDTO).collect(Collectors.toList());}
    public NotificacionResponseDTO crear(NotificacionRequestDTO dto){
        Notificacion n=Notificacion.builder().idCliente(dto.getIdCliente()).tipo(dto.getTipo())
                .mensaje(dto.getMensaje()).fechaEnvio(LocalDateTime.now()).leida(false).build();
        return toDTO(repo.save(n));}
    public NotificacionResponseDTO marcarLeida(Long id){
        Notificacion n=repo.findById(id).orElseThrow(()->new NotificacionNotFoundException(id));
        n.setLeida(true);return toDTO(repo.save(n));}
    private NotificacionResponseDTO toDTO(Notificacion n){return NotificacionResponseDTO.builder()
            .idNotificacion(n.getIdNotificacion()).idCliente(n.getIdCliente()).tipo(n.getTipo())
            .mensaje(n.getMensaje()).fechaEnvio(n.getFechaEnvio()).leida(n.getLeida()).build();}
}
