package com.SistemaDeReserva.msnotificaciones.repository;
import com.SistemaDeReserva.msnotificaciones.model.Notificacion;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface NotificacionRepository extends JpaRepository<Notificacion,Long> {
    List<Notificacion> findByIdCliente(Long idCliente);
    List<Notificacion> findByIdClienteAndLeidaFalse(Long idCliente);
}
